// const express=require('express')
// const app=express()
// const bodyparser=require('body-parser')
// const path=require('path')
// const staticpath=(path.join(__dirname))
// var url=bodyparser.urlencoded({extended:false})
// app.use(express.static(staticpath,{index:'student.html'}))
// app.post("/process",url,(req,res)=>
// {
//     res.write(`Firstname:${req.body.firstname} lastname:${req.body.lastname}`)
//     res.end()
// })
// app.listen(400)

// write a exp js script to perform the task as asked below 
// 1.create one html file named lj form .html and one form which contains user name and password, gender and submit button
// data should be submitted by http post method
// 2.submit button is of black color and white text used ext css 

const express=require('express')
const app=express()
const bodyparser=require('body-parser')
const path=require('path')
const staticpath=(path.join(__dirname))
var url=bodyparser.urlencoded({extended:false})
app.use(express.static(staticpath,{index:'1t.html'}))
app.post('/process',url,(req,res)=>

{
    res.write(`firstname: ${req.body.username} password: ${req.body.password} gender: ${req.body.gender}` )
    res.end()   
})
app.listen(5000,()=>
{
    console.log('Run')
})

// write a exp js script to write a task below
// 1 create one html file frontend.html and add one form which contains name,password and submit button data should be 
// submitted by http post method process by on homepage form should be displayed and while submitting the form on next page
// name / login if username is admin then it will display welcome admin else display warning message in red color please
// login with admin name