const express=require('express')
const app=express()
const path=require('path')
app.get("/file",(req,res)=>{
    res.sendFile(path.join(__dirname,'luffy.png'))
})
app.listen(5000)

// sending a single file name task.html on a route with use of send file function
// const express=require('express')
// const app=express()
// const path=require('path')
// app.get("/file",(req,res)=>{
//     res.sendFile(path.join(__dirname,'task.html'))
// })
// app.listen(5000)

// write express js script to print msg in next line splitting by . and use the get method to submit the data html file
// contains a form of textarea for the msg and submit button 