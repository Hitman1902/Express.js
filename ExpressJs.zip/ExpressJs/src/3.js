// write exp js script to print message in next line splitting by . use the get method to submit the data html file contains
// a form of text area for the message and submit button
// const express=require('express')
// const app=express()
// const path=require('path')
// const staticpath=path.join(__dirname,"../src")
// app.use(express.static(staticpath,{index:'12.html'}))
// app.get("/Process_get",(req,res)=>
// {
//     res.set('content-Type','text/html')
//     t1=(req.query.Textarea).split(".")
//     for (i in t1)
//         {
//             res.write(t1[i]+"<br>")
//         }
// })
// app.listen(5000,()=>
// {
//     console.log("Run")
// })

// write a exp js to perform task as ask below 
// 1.create one html file which contains two number type input field,one dropdown which contains options like
// select,addition,substraction,multplication,division and one submit button the input fields must contain the 
// value >0 else it will give a message please enter the valid message also user must select any of the formula
// from the dropdown else give a message you have not selected any formula 
// Note:- message will be display on /Calculator page 
// 3.If one formula is selected and numbers are entered then 
// on the same page
// 4. Use get method to req the data
const express=require('express')
const app=express()
const path=require('path')
const staticpath=path.join(__dirname,'../src')
app.use(express.static(staticpath,{index:'12.html'}))
app.get("/process_get",(req,res)=>
{
    n1=parseInt(req.query.n1)
    n2=parseInt(req.query.n2)
    if((n1>0) && (n2>0))
        {
            if(req.query.choice=='add')
                {
                    a=n1+n2
                    res.write(a.toString())
                }
            else if(req.query.choice=='sub')
                {
                    b=n1-n2
                    res.write(b.toString())
                }
            else if(req.query.choice=='mul')
                {
                    c=n1*n2
                    res.write(c.toString())
                }
            else if(req.query.choice=='div')
                {
                    d=n1/n2
                    res.write(d.toString())
                }
            else{
                res.write('enter valid choice')
            }
        }
    else{
        res.write('enter valid number')
       }
       res.end()
})
app.listen(500,()=>
{
    console.log('Run')
})
tiyum,kyui