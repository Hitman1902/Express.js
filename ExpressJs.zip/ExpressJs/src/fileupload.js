const express=require('express')
const app=express()
const multer=require('multer')
app.get('/',(req,res)=>
{
    res.sendFile(__dirname+'/fileupload.html')
})
var storage=multer.diskStorage(
    {
        destination:'single',
        filename:function(req,file,cb)
        {
            cb(null,file.originalname)
        }
    }
)
var upload=multer(
    {
        storage:storage
    }
)
app.post('/uploadfile',upload.single('mypic'),(req,res)=>
{
    const file=req.file
    if(file)
        {
            res.send("<h1>file"+file.orginalnmae+'has been uploaded in'+file.destination+'folder')
        }
})
app.listen(4500,()=>
{
    console.log('Run')
})