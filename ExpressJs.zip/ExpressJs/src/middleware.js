const express=require("express")
const app=express()
const path=require('path')
const staticPath=path.join(__dirname)
app.use(express.static(staticPath,{index:"mid.html"}))
app.get('/login',(req,res,next)=>
{
    res.set('content-Type','text/html')
    res.write("<h1>Welcome"+req.query.name+"</h1><br><h1>Your email id "+req.query.email+"</h1>")
    next();
})
app.get('/login',(req,res,next)=>
{
    if(req.query.sb=='on')
        {
            res.write("<h1>Thank you for subscribe</h1><a href='/'>Logout</a>")
        }
    else{
            res.write("<h1>you can subscribe for get daily update</h1><a href='/sub'>Subscribe</a>")
            next();

    }
})
app.get("/sub",(req,res)=>
{
    res.set('content-type','text/html')
    res.write("<h1>Thank you for subscribe</h1><a href='/'>Logout</a>")
    res.send()
})
app.listen(5001,()=>
{
    console.log('Run')
})