const express=require('express')
const app=express()
const path=require('path')
const bodyparser=require('body-parser')
const staticpath=(path.join(__dirname))
var url=bodyparser.urlencoded({extended:false})
app.use(express.static(staticpath,{index:'1t.html'}))
app.get('/process',(req,res,next)=>
{
    res.set('content-Type','text/html')
    res.write(`<h1>Welcome ${req.query.name}</h1><br><h1>Your email id ${req.query.email}</h1>`)
})
app.get('/process',(req,res,next)=>
{
    if(req.query.subscribe=='on')
        {
            res.set('content-Type','text/html')
            res.write(`<h1>Welcome ${req.query.name}</h1><br><h1>Your email id ${req.query.email}</h1><br><h1>Thank you for subscribe</h1><a href='#/'>Logout</a>`)
            next()
        }
    else{
            res.set('content-Type','text/html')
            res.write(`<h1>Welcome ${req.query.name}</h1><br><h1>Your email id ${req.query.email}</h1><br><h1>you can subscribe for get daily update</h1><a href='#/'>Logout</a>`)
            next()
    }
})