const express=require('express')
const app=express()
const path=require('path')
const staticpath=path.join(__dirname,"../src")
app.use(express.static(staticpath,{index:'task.html'}))
app.get('/Process_get',(req,res)=>{
    const response={u:req.query.Username,
        p:req.query.Password
    }
    console.log(response)
    res.send(response)
})
app.listen(500)