// const express=require('express')
// const app=express()
// const cp=require('cookie-parser')
// app.use(cp())
// app.get('/',(req,res)=>
// {
//     res.cookie('FSD','EXPRESS')
//     res.send('cookie set')
// })
// app.get('/home',(req,res)=>
//     {
//        console.log(req.cookies)
//         res.send(req.cookies)
//     })
// app.get('/delete',(req,res)=>
//     {
//         res.clearCookie('FSD')
//         res.send('Cookie deleted')
//     })
// app.listen(5000)
// write script to create a login form

// const express=require('express')
// const app=express()
// const cp=require('cookie-parser')
// app.use(cp())
// app.get('/',(req,res)=>
// {
//     res.sendFile(__dirname+'/1t.html')
// })
// app.get('/next',(req,res,next)=>
// {
//     const response={u:req.query.uname,
//         P:req.query.pss
//     }
//     res.cookie('uname: ',response.u)
//     next()
// })
// app.get('/next',(req,res)=>
// {
//     console.log(req.cookies)
//     res.send(req.cookies)
// })
// app.listen(5000,()=>
// {
//     console.log('Run')
// })

/* 1) u have been assign t develop a user feedback form for a website using express js & cookies implement the following 
requirement

---> create form with following field name,email,message,rating("bad","average","good","very good","excellent")
when user submit the form store their feedback info in a cookie named feedback that expires in 10 sec ,Display
message after suucessfully submitting form & create a link to display the feedback details srtored in feeback cookie
when user click to link retrive the fedback info from cookie & display it tp page also include a link on feedback 
details page to logout when user click link user redirected to home page  */

const express = require("express");
const cp = require("cookie-parser");
const app = express();
app.use(cp());
app.get("/", (req, res) => {
  res.sendFile(__dirname + "/1t.html");
});
app.get("/submit-feedback", (req, res) => {
  const { name, email, message, rating } = req.query;

  // Create the feedback object
  const feedback = {
    name,
    email,
    message,
    rating,
  };
  // Set the feedback cookie with a 10-second expiration
  res.cookie("feedback", feedback, { maxAge: 10000 });
  res.send(
    'Thank you for your feedback! <br> <a href="/feedback-details"> Show Feedback </a>'
  );
});

app.get("/feedback-details", (req, res) => {
  const feedback = req.cookies.feedback;

  if (feedback) {
    res.send(`
      <h1>Feedback Details</h1>
      <p><strong>Name:</strong> ${feedback.name}</p>
      <p><strong>Email:</strong> ${feedback.email}</p>
      <p><strong>Message:</strong> ${feedback.message}</p>
      <p><strong>Rating:</strong> ${feedback.rating}</p> 
      <a href="/" > logout </a>`);
  } else {
    res.send("No feedback available.");
  }
});

app.listen(5151, () => {
  console.log("Server is running on port 5000");
});
