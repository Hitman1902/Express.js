const nm=require('nodemailer')
var trans=nm.createTransport({
    host:'smtp.gmail.com',
    port:465,
    auth:
    {
        user:'sender@gmail.com',
        pass:""
    }
})
var mailoption={
    from:'sender@gmail.com',
    to:'receiver@gmail.com',
    subject:'Hello',
    text:'test mail',
    html:'testingnode mailer,<h1>Eeffect of h1 </h1>'
}
trans.sendMail(mailoption,(err,info)=>
{
    if(err)
        {
            console.log(err)
        }
    console.log(info)
})