const express=require('express')
const app=express()
const bodyParser=require('body-parser')
var url=bodyParser.urlencoded()
app.set('view engine',"pug")
app.get("/",(req,res)=>
{
    res.render(__dirname+"/form")
})
app.post("/login",url,(req,res)=>
{
    const {name,password}=req.body;
    res.render(__dirname+"/display",{name:name,password:password})
})
app.listen(8080,()=>
{
    console.log('Run')
})