// const express=require('express')
// const app=express()
// app.get('/',(req,res)=>
// {
//     const user=[{
//         id:1,name:'xyz'
//     },{
//         id:2,name:'PQR'
//     },{
//         id:3,name:'DEF'
//     }]
//     res.set('content-Type','application/json')
//     res.send(user)
// })
// app.listen(8000)

// write a express js script to define 1 json array of 3 objects having members name and age sort these objects according to
// age name must be sorted if user req /sorted names to url then all names should be printed according to the ascending order of age 
// const express = require('express');
// const app = express();

// const objs = [
//   { name: 'John', age: 25 },
//   { name: 'Alice', age: 30 },
//   { name: 'Bob', age: 20 }
// ];

// app.get('/sorted/names', (req, res) => {
//   objs.sort((a, b) => a.age - b.age || a.name.localeCompare(b.name));
//   const names = objs.map(obj => obj.name);
//   res.send(names.join(', '));
// });

// app.listen(3000, () => {
//   console.log('Server listening on port 3000');
// });

// write a express js of req server json object (array objects) in table form on browser 
const express=require('express')
const app=express()
const student={A1:[{name:'LJ',id:1},{name:'LJ1',id:2},{name:'LJ2',id:3}]}
app.get('/',(req,res)=>
{
    res.set('Content-Type','text/html')
    res.write("<table border='2px solid red'><tr><th>name</th><th>id</th></tr>")
    for (i in student.A1)
        {
            res.write("<tr><td>"+i.name+"</td>")
            res.write("<td>"+i.id+"</td></tr>")
        }
        res.write("</table>")
    })
app.listen(2000)