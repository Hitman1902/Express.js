// const express=require('express')
// const app=express()
// app.get('/',(req,res)=>
// {
//     res.write("Hello Home Page")
//     res.send()
// })
// app.listen(500,()=>
// {
//     console.log('Run')
// })
// app.get('/about',(req,res)=>
// {
//     res.send("Hello about Page")
// })
// app.get('/content',(req,res)=>
// {
//     res.status(200)
//     res.set('content-Type','text/html')
//     res.send('<h1>Hello</h1>')
// })

// create a webpage using express js on which the homepage displays homepage in big blue font student page shows welcome to student page 
// in blue color and italic font render response routing 
const express=require('express')
const app=express()
app.get('/',(req,res)=>
{
    res.status(200)
    res.set('content-Type','text/html')
    res.write("<h1 style='color:blue'>Hello Home Page</h1>")
    res.send()
})
app.listen(500,()=>
{
    console.log('Run')
})
app.get('/Student',(req,res)=>
{
    res.status(200)
    res.set('content-Type','text/html')
    res.send("<i style='color:blue'>Hello student Page</i>")
})
app.get('/content',(req,res)=>
{
    res.status(200)
    res.set('content-Type','text/html')
    res.send('<h1>Hello</h1>')
})